getwd()
setwd("C:\\Users\\it24101398\\Desktop\\IT24101398\\Lab6")
getwd()
#Q1
#Binomal distribution
pbinom(46,50,0.85)

#Q2
#Number of calls received in given day
#poisson distribution
dpois(15,12)
