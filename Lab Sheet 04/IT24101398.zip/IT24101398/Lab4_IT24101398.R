setwd("C:\\Users\\IT24101398\\Desktop\\IT24101398")
getwd()
branch_data <-read.table("Exercise.txt",header = TRUE,sep = ",")
head(branch_data)

checck_varia<- function(x){
  if(is.numeric(x)){
    return("Numeric (Ratio scale)")
  }else if(is.factor(x)||is.character(x)){
    return("")
  }
}