
> observed <- c(120, 95, 85, 100)
> chisq.test(x=observed)
Chi-squared test for given probabilities
data: observed
X-squared 6.5, df
=
  3, p-value = 0.08966
> file_path <- "C:\\IT\\Y2 Sem 1\\PS\\Lab Sheets \\Labsheets \\Lab 10-20251014\\Lab 10-1T24101398\\Lab 10-IT24102286\\Data CSV"
> snacks <- read.csv(file_path, row.names = 1)
› snacks
wife Alternating Husband Jointly
Laundry
156
14
2
4
Main_meal 124
20
5
4
Dinner
77
11
7
13
Breakfeast 82
36
15
7
Tidying
53
11
1
57
Dishes
32
24
4
53
Shopping
33
23
9
55
official
12
46
23
15
Driving
10
51
75
3
Finances
13
13
Insurance
8
Repairs
0
Holidays
IMHMH
21
66
1
53
77
3
160
2
1
6
153
> chisq.test(snacks)
Pearson's Chi-squared test
data: snacks
X-squared
=
1944.5, df =
36, p-value < 2.2e-16
> |